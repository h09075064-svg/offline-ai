# Offline AI — Phase 1 — Phone-Only Build Guide

You don't have a PC, so Android Studio (which only runs on a desktop) is
out. Instead, we'll build the app on **GitHub's free cloud servers**,
controlled entirely from your phone's browser. You never need a
computer.

Total one-time setup: ~20 minutes. After that, the app just lives on
your phone and runs 100% offline like normal.

---

## Step 1 — Create a free GitHub account

1. Open your phone's browser, go to **github.com**, tap **Sign up**.
2. Follow the prompts (email, username, password). Verify your email.

## Step 2 — Create a new repository

1. Tap the **+** icon (top right) → **New repository**.
2. Name it `offline-ai` (or anything).
3. Set it to **Public** (needed for free Actions minutes) or Private if
   you don't mind using your free private-repo Actions quota.
4. Tap **Create repository**. Leave it empty for now.

## Step 3 — Upload the project files

GitHub's website lets you upload files/folders straight from your phone:

1. On your new repo's page, tap **Add file → Upload files**.
2. Tap to browse, and select the **`OfflineAI` folder's contents** — the
   easiest way on mobile is to upload the whole unzipped folder if your
   phone's file picker supports folder upload (most Android browsers do
   via "Files" app integration). Otherwise, upload each top-level item
   individually: `app/`, `.github/`, `build.gradle.kts`,
   `settings.gradle.kts`, `gradle.properties`, `README.md`.
3. Scroll down, tap **Commit changes**.

   *Tip:* if folder upload is fiddly on your phone's browser, the GitHub
   mobile app (Play Store) has a smoother "upload from device" flow for
   nested folders — same result either way.

## Step 4 — Let it build

1. Go to the **Actions** tab of your repo.
2. You should see a workflow run start automatically ("Build APK"). If
   not, tap **Build APK** in the left sidebar → **Run workflow**.
3. Tap into the running job and watch it — first run takes ~10–15
   minutes (it's compiling llama.cpp from source in the cloud).
4. If it fails, tap the red step to see the error and send it to me —
   I'll patch the source directly. This is genuinely normal for
   native-code projects; don't worry if the first attempt needs a fix.

## Step 5 — Download the APK to your phone

1. Once the run finishes with a green checkmark, scroll down to
   **Artifacts** and tap **OfflineAI-debug-apk** to download it
   (downloads as a .zip containing the .apk).
2. Open your phone's Downloads, extract the zip (most file manager apps
   can do this with a tap), and you'll have `app-debug.apk`.
3. Tap the APK to install. Android will warn about "unknown sources" —
   this is expected for an app not from the Play Store; allow it for
   your Files/Browser app in Settings when prompted.

## Step 6 — Get a model

1. In your phone's browser, go to Hugging Face and search **"Llama 3.2
   1B Instruct GGUF"**. Pick a well-known quantizer (e.g. `bartowski`).
2. Download the **Q4_K_M** file (~700MB–1GB) — it'll land in your
   Downloads folder.

## Step 7 — Load the model and chat

1. Open the **Offline AI** app.
2. Tap **Load model** (top right).
3. Browse to your Downloads folder and select the `.gguf` file you
   downloaded.
4. Wait for the status line to say "Loaded …" — then type a message and
   hit Send. Everything from here runs entirely on your phone's CPU.

---

## Why this works

GitHub Actions' build servers act as your "PC" for the one-time
compilation step. The output — the `.apk` file — is a normal Android
app package that installs and runs on your phone exactly like anything
from the Play Store, with zero dependency on GitHub or the internet
afterward. Once installed, the app never makes a network call.

## If a build fails

Native Android builds are finicky even for experienced developers on a
PC — doing it via cloud CI is genuinely the harder path, so don't be
discouraged by a red X on the first try. Copy the error text from the
failed Actions step and send it to me; I'll fix the source file it
points to.

## What's next (Phase 2)

Hardware auto-tuning, hot model switching, and a proper model manager UI
— tell me once chat is working and we'll move on.
