# Add project specific ProGuard rules here.
-keep class com.offlineai.app.llm.LlamaBridge { *; }
