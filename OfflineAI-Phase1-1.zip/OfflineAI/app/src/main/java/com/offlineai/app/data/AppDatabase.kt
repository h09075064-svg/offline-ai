package com.offlineai.app.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SupportFactory
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.spec.GCMParameterSpec

@Database(entities = [Message::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: build(context).also { instance = it }
            }

        private fun build(context: Context): AppDatabase {
            SQLiteDatabase.loadLibs(context)
            val passphrase = LocalKeyManager.getOrCreateDbPassphrase(context)
            val factory = SupportFactory(passphrase)
            return Room.databaseBuilder(context, AppDatabase::class.java, "offline_ai.db")
                .openHelperFactory(factory)
                .build()
        }
    }
}

/**
 * Generates and stores a random passphrase for the local SQLCipher database.
 * The passphrase itself is wrapped with a key that lives in the Android
 * Keystore (hardware-backed on most devices), so it never appears in
 * plaintext in app storage. Nothing here ever touches the network.
 */
private object LocalKeyManager {
    private const val KEYSTORE_ALIAS = "offline_ai_db_key"
    private const val PREFS_NAME = "offline_ai_secure_prefs"

    fun getOrCreateDbPassphrase(context: Context): ByteArray {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val existing = prefs.getString("wrapped_passphrase", null)
        val iv = prefs.getString("iv", null)

        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (!keyStore.containsAlias(KEYSTORE_ALIAS)) {
            val keyGen = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore"
            )
            keyGen.init(
                KeyGenParameterSpec.Builder(
                    KEYSTORE_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .build()
            )
            keyGen.generateKey()
        }
        val secretKey = keyStore.getKey(KEYSTORE_ALIAS, null)

        if (existing != null && iv != null) {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(128, android.util.Base64.decode(iv, android.util.Base64.NO_WRAP)))
            return cipher.doFinal(android.util.Base64.decode(existing, android.util.Base64.NO_WRAP))
        }

        // First run: generate a fresh random passphrase for the DB and wrap it.
        val newPassphrase = UUID.randomUUID().toString().toByteArray()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey)
        val encrypted = cipher.doFinal(newPassphrase)
        prefs.edit()
            .putString("wrapped_passphrase", android.util.Base64.encodeToString(encrypted, android.util.Base64.NO_WRAP))
            .putString("iv", android.util.Base64.encodeToString(cipher.iv, android.util.Base64.NO_WRAP))
            .apply()
        return newPassphrase
    }
}
