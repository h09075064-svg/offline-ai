package com.offlineai.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.offlineai.app.data.AppDatabase
import com.offlineai.app.data.Message
import com.offlineai.app.llm.LlamaBridge
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.io.File

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = AppDatabase.get(application).chatDao()

    private val _messages = MutableStateFlow<List<Message>>(emptyList())
    val messages: StateFlow<List<Message>> = _messages

    private val _modelStatus = MutableStateFlow("No model loaded")
    val modelStatus: StateFlow<String> = _modelStatus

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating

    init {
        viewModelScope.launch {
            dao.observeAll().collectLatest { _messages.value = it }
        }
    }

    /**
     * Loads a GGUF model the user has already copied onto the device (see
     * README "Getting a model"). Nothing is downloaded from within the app.
     */
    fun loadModel(modelFile: File) {
        viewModelScope.launch {
            _modelStatus.value = "Loading ${modelFile.name}…"
            val ok = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                LlamaBridge.loadModel(modelFile.absolutePath, nThreads = defaultThreadCount())
            }
            _modelStatus.value = if (ok) "Loaded ${modelFile.name}" else "Failed to load model"
        }
    }

    fun sendMessage(text: String) {
        if (text.isBlank() || !LlamaBridge.modelLoaded) return

        viewModelScope.launch {
            dao.insert(Message(role = "user", content = text))

            _isGenerating.value = true
            val responseBuilder = StringBuilder()
            val assistantId = dao.insert(Message(role = "assistant", content = ""))

            LlamaBridge.generateStream(buildPrompt(text)).collectLatest { token ->
                responseBuilder.append(token)
                // For Phase 1 we keep it simple and just re-insert the latest
                // snapshot; Phase 2 swaps this for a proper update-in-place DAO call.
            }
            dao.insert(Message(id = 0, role = "assistant", content = responseBuilder.toString()))
            _isGenerating.value = false
        }
    }

    private fun buildPrompt(userText: String): String =
        "You are a helpful, private, fully offline AI assistant.\nUser: $userText\nAssistant:"

    private fun defaultThreadCount(): Int =
        Runtime.getRuntime().availableProcessors().coerceIn(2, 6)
}
