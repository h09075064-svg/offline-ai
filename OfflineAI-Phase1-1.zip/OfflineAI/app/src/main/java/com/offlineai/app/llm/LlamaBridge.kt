package com.offlineai.app.llm

import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/**
 * Thin Kotlin wrapper around the native llama.cpp engine (see
 * app/src/main/cpp/native-lib.cpp). Every call here stays on-device;
 * there is no network path anywhere in this class.
 */
object LlamaBridge {
    init {
        System.loadLibrary("offlineai_native")
    }

    // --- native functions, implemented in native-lib.cpp ---
    private external fun nativeLoadModel(modelPath: String, nThreads: Int, contextSize: Int): Boolean
    private external fun nativeGenerate(prompt: String, maxTokens: Int, callback: TokenCallback)
    private external fun nativeUnload()
    private external fun nativeIsLoaded(): Boolean

    fun interface TokenCallback {
        fun onToken(token: String)
    }

    var modelLoaded: Boolean = false
        private set

    /**
     * Loads a GGUF model from local storage. [nThreads] and [contextSize]
     * should come from HardwareProfiler (Phase 2) — for Phase 1 sensible
     * defaults are passed in from the ViewModel.
     */
    fun loadModel(modelPath: String, nThreads: Int = 4, contextSize: Int = 2048): Boolean {
        val ok = nativeLoadModel(modelPath, nThreads, contextSize)
        modelLoaded = ok
        return ok
    }

    fun unload() {
        nativeUnload()
        modelLoaded = false
    }

    /**
     * Streams generated tokens as they come off the model. Collect this
     * Flow from a coroutine to render text as it's produced.
     */
    fun generateStream(prompt: String, maxTokens: Int = 512): Flow<String> = callbackFlow {
        nativeGenerate(prompt, maxTokens) { token ->
            trySend(token)
        }
        close()
        awaitClose { }
    }
}
