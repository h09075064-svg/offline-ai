package com.offlineai.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A single chat turn, stored locally only. Nothing about this object
 * ever leaves the device.
 */
@Entity(tableName = "messages")
data class Message(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,          // "user" or "assistant"
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)
