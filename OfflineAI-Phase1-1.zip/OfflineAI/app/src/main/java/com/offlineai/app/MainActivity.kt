package com.offlineai.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.offlineai.app.ui.ChatScreen
import java.io.File

class MainActivity : ComponentActivity() {

    private val viewModel: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Phase 1: any .gguf previously imported by the picker below is cached
        // in the app's own storage, so re-launching the app auto-loads it.
        val modelsDir = File(getExternalFilesDir(null), "models")
        modelsDir.mkdirs()
        modelsDir.listFiles { f -> f.extension == "gguf" }?.firstOrNull()?.let { model ->
            viewModel.loadModel(model)
        }

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val context = LocalContext.current
                    val pickModel = rememberLauncherForActivityResult(
                        ActivityResultContracts.OpenDocument()
                    ) { uri: Uri? ->
                        uri ?: return@rememberLauncherForActivityResult
                        // Copy the picked file (e.g. from Downloads) into the app's
                        // own storage, since that's the only path native code can
                        // open directly by filesystem path.
                        val dest = File(modelsDir, "model.gguf")
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            dest.outputStream().use { output -> input.copyTo(output) }
                        }
                        viewModel.loadModel(dest)
                    }

                    ChatScreen(
                        viewModel = viewModel,
                        onPickModel = { pickModel.launch(arrayOf("*/*")) }
                    )
                }
            }
        }
    }
}
